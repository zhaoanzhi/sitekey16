"""Create an explicit allowlisted public bundle; never include local signing files."""
from pathlib import Path
import hashlib, shutil, zipfile
root = Path(__file__).resolve().parent
target = root / 'publish'
target.mkdir(exist_ok=True)
for name in ('index.html', '.nojekyll'):
    shutil.copyfile(root / 'web' / name, target / name)
apk = root / 'artifacts/SiteKey16-v1.0-compatible.apk'
shutil.copyfile(apk, target / apk.name)
with zipfile.ZipFile(apk) as archive:
    assert archive.read('assets/index.html') == (target / 'index.html').read_bytes()
sources = [root / name for name in ('README.md', '.gitignore', 'build-apk.py', 'package-public.py')]
for folder in ('web', 'android', 'tests'):
    sources.extend(p for p in (root / folder).rglob('*') if p.is_file())
with zipfile.ZipFile(target / 'SiteKey16-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(sources): archive.write(path, path.relative_to(root))
test = (root / 'tests/compatibility.mjs').read_text(encoding='utf-8')
(target / 'compatibility.mjs').write_text(test.replace("../web/index.html", "./index.html"), encoding='utf-8')
intro = '''# SiteKey 16

[打开静态网站](https://zhaoanzhi.github.io/sitekey16/) · [下载 Android APK](./SiteKey16-v1.0-compatible.apk) · [下载完整源码](./SiteKey16-source.zip)

这是纯静态 GitHub Pages 页面和共用同一 HTML 的离线 APK。Android 8.0 及以上可安装；新包名不会覆盖旧 APK。

仓库根目录的网页直接用于 Pages；完整 Android 源码、构建脚本及旧 APK 差分测试在 **SiteKey16-source.zip** 中。

在仓库根目录运行 `node compatibility.mjs` 可验证网页；解压完整源码后，按下文构建说明使用。GitHub Actions 每次提交会校验四组官方向量和边界输入。

'''
readme = (root / 'README.md').read_text(encoding='utf-8')
(target / 'README.md').write_text(intro + readme[readme.index('## 使用'):], encoding='utf-8')
checksums = []
for name in ('SiteKey16-v1.0-compatible.apk', 'SiteKey16-source.zip', 'index.html'):
    checksums.append(hashlib.sha256((target / name).read_bytes()).hexdigest() + '  ' + name)
(target / 'SHA256SUMS.txt').write_text('\n'.join(checksums) + '\n', encoding='utf-8')
print('Public bundle:', target)
for path in sorted(target.iterdir()): print(path.name, path.stat().st_size)
