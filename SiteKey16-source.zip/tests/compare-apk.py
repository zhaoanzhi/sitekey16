"""Extract the provided original APK's algorithm to compare locally, without redistributing the APK."""
import pathlib, re, subprocess, sys, zipfile
apk = pathlib.Path(sys.argv[1])
with zipfile.ZipFile(apk) as archive:
    libraries = [name for name in archive.namelist() if name.endswith('/libmain.so')]
    for library in libraries:
        data = archive.read(library)
        start = data.index(b'<!doctype html>')
        end = data.index(b'</html>', start) + len(b'</html>')
        html = data[start:end].decode('utf-8')
        script = re.search(r'<script>([\s\S]*?)</script>', html).group(1)
        core = script[script.index('function utf8'):script.index('var master=document')]
        subprocess.run(['node', str(pathlib.Path(__file__).with_name('compare-original.mjs'))], input=core, encoding='utf-8', check=True)
        print('PASS original APK architecture:', library)
