import {readFileSync} from 'node:fs';
import {webcrypto} from 'node:crypto';
import {runInNewContext} from 'node:vm';
import assert from 'node:assert/strict';
const original = {};
runInNewContext(readFileSync(0, 'utf8'), original);
const html = readFileSync(new URL('../web/index.html', import.meta.url), 'utf8');
const current = {crypto: webcrypto, TextEncoder, Uint8Array};
runInNewContext(html.match(/<script id="sitekey16-core">([\s\S]*?)<\/script>/)[1], current);
const api = current.SiteKey16;
const sites = ['Google.com', 'https://www.github.com/login?x=1', ' Steam ', 'www.google.com/path?q=1', 'https://www.Example.COM.../a', 'www.www.example.com', 'www2.example.com:8443', '子域.例子.中国', 'ftp://example.com/path', 'İ.example', 'sub.example.co.uk', '\uFEFFexample.com\u00A0'];
const alphabet = Array.from('aAzZ09 !@#\\0é中🙂\u0301\n\t');
let seed = 23806;
function random() { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed; }
for (let i = 0; i < 1200; i++) {
  const master = Array.from({length: i % 81}, () => alphabet[random() % alphabet.length]).join('');
  const site = sites[i % sites.length];
  const actual = await api.derive(master, site);
  assert.equal(actual.password, original.derive(master, site));
  assert.equal(actual.normalizedSite, original.normalizeSite(site));
}
for (const [master, site, , , expected] of api.vectors) assert.equal(original.derive(master, site), expected);
// The old UI normalized once before calling derive, which normalized a second time.
// User chose the attachment contract: the new UI must normalize only once for calculation.
assert.notEqual(original.derive('abc123', original.normalizeSite('www.www.example.com')), (await api.derive('abc123', 'www.www.example.com')).password);
console.log('PASS 1200 deterministic differential cases and 4 official vectors against extracted APK v1 core');
