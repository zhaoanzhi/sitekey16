"""Build the offline APK with Android SDK tools and a local, unpublished signing key."""
from pathlib import Path
import argparse, hashlib, os, secrets, shutil, subprocess, zipfile

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--sdk', default=os.environ.get('ANDROID_HOME', str(Path.home() / 'AppData/Local/Android/Sdk')))
parser.add_argument('--java-home', default=os.environ.get('JAVA_HOME'))
args = parser.parse_args()
sdk = Path(args.sdk)
def version(path):
    return tuple(int(x) if x.isdigit() else 0 for x in path.name.replace('android-', '').split('.'))
bt = sorted((sdk / 'build-tools').iterdir(), key=version)[-1]
platform = sorted((sdk / 'platforms').iterdir(), key=version)[-1] / 'android.jar'
env = os.environ.copy()
if args.java_home:
    env['JAVA_HOME'] = args.java_home
    env['PATH'] = str(Path(args.java_home) / 'bin') + os.pathsep + env['PATH']
def run(*command):
    subprocess.run([str(x) for x in command], cwd=ROOT, env=env, check=True)
build = ROOT / 'build'
assets, classes, dex = [build / x for x in ('assets', 'classes', 'dex')]
artifacts, private = ROOT / 'artifacts', ROOT / 'private'
for directory in (assets, classes, dex, artifacts, private): directory.mkdir(parents=True, exist_ok=True)
# Work from local JAR copies so JDK ZIP filesystem access does not resolve protected SDK directories.
cache = build / 'sdk-cache'
cache.mkdir(exist_ok=True)
shutil.copyfile(platform, cache / 'android.jar')
platform = cache / 'android.jar'
for name in ('d8.jar', 'apksigner.jar'): shutil.copyfile(bt / 'lib' / name, cache / name)
run('node', ROOT / 'tests/compatibility.mjs')
shutil.copyfile(ROOT / 'web/index.html', assets / 'index.html')
run(bt / 'aapt.exe', 'package', '-f', '-M', ROOT / 'android/AndroidManifest.xml', '-S', ROOT / 'android/res', '-A', assets, '-I', platform, '-F', build / 'resources.apk')
sources = sorted((ROOT / 'android/src').rglob('*.java'))
run('javac', '-encoding', 'UTF-8', '-source', '8', '-target', '8', '-bootclasspath', platform, '-d', classes, *sources)
run('java', '-cp', cache / 'd8.jar', 'com.android.tools.r8.D8', '--min-api', '26', '--lib', platform, '--output', dex, *sorted(classes.rglob('*.class')))
unsigned = build / 'unsigned.apk'
shutil.copyfile(build / 'resources.apk', unsigned)
with zipfile.ZipFile(unsigned, 'a', compression=zipfile.ZIP_DEFLATED) as archive:
    archive.write(dex / 'classes.dex', 'classes.dex')
run(bt / 'zipalign.exe', '-f', '4', unsigned, build / 'aligned.apk')
keystore, password_file = private / 'sitekey16.jks', private / 'signing-password.txt'
if keystore.exists() != password_file.exists():
    raise RuntimeError('Signing key/password is missing. Restore the private signing files before rebuilding.')
if not keystore.exists():
    password_file.write_text(secrets.token_urlsafe(32), encoding='utf-8')
env['SITEKEY_STOREPASS'] = password_file.read_text(encoding='utf-8').strip()
if not keystore.exists():
    run('keytool', '-genkeypair', '-noprompt', '-keystore', keystore, '-storepass:env', 'SITEKEY_STOREPASS', '-keypass:env', 'SITEKEY_STOREPASS', '-alias', 'sitekey16', '-keyalg', 'RSA', '-keysize', '3072', '-validity', '10000', '-dname', 'CN=SiteKey 16 Offline')
apk = artifacts / 'SiteKey16-v1.0-compatible.apk'
run('java', '-jar', cache / 'apksigner.jar', 'sign', '--ks', keystore, '--ks-key-alias', 'sitekey16', '--ks-pass', 'env:SITEKEY_STOREPASS', '--key-pass', 'env:SITEKEY_STOREPASS', '--out', apk, build / 'aligned.apk')
run('java', '-jar', cache / 'apksigner.jar', 'verify', '--verbose', apk)
with zipfile.ZipFile(apk) as archive:
    assert archive.read('assets/index.html') == (ROOT / 'web/index.html').read_bytes(), 'APK/web asset mismatch'
digest = hashlib.sha256(apk.read_bytes()).hexdigest()
(artifacts / 'SHA256SUMS.txt').write_text(f'{digest}  {apk.name}\n', encoding='utf-8')
print('PASS: signed APK contains a byte-identical copy of web/index.html')
print(f'APK: {apk}')
print(f'SHA256: {digest}')
