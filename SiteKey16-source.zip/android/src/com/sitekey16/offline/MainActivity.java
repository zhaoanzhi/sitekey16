package com.sitekey16.offline;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Offline shell. All v1 calculation and compatibility tests live in assets/index.html. */
public final class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff0b1020);
        getWindow().setNavigationBarColor(0xff0b1020);
        web = new WebView(this);
        web.setBackgroundColor(0xff0b1020);
        web.setSaveEnabled(false);
        web.setImportantForAutofill(WebView.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setDatabaseEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setBlockNetworkLoads(true);
        android.webkit.CookieManager.getInstance().setAcceptCookie(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
        });
        web.addJavascriptInterface(new ClipboardBridge(), "SiteKeyClipboard");
        setContentView(web);
        try (InputStream stream = getAssets().open("index.html")) {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] bytes = new byte[8192]; int count;
            while ((count = stream.read(bytes)) != -1) buffer.write(bytes, 0, count);
            // HTTPS base establishes a secure context for Web Crypto. No network request is made.
            web.loadDataWithBaseURL("https://appassets.androidplatform.net/", buffer.toString(StandardCharsets.UTF_8.name()), "text/html", "UTF-8", null);
        } catch (Exception failure) {
            android.widget.TextView error = new android.widget.TextView(this);
            error.setText("无法读取离线页面，请重新安装 SiteKey 16。"); setContentView(error);
        }
    }

    private final class ClipboardBridge {
        @JavascriptInterface public boolean copy(String password) {
            if (password == null || !password.matches("[ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*_+=\\-]{16}")) return false;
            try {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("SiteKey 16", password);
                android.os.PersistableBundle extras = new android.os.PersistableBundle();
                extras.putBoolean("android.content.extra.IS_SENSITIVE", true);
                clip.getDescription().setExtras(extras);
                clipboard.setPrimaryClip(clip);
                return true;
            } catch (RuntimeException unavailable) { return false; }
        }
    }

    @Override protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("SiteKeyClipboard"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
